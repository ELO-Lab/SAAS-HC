/* This file has been generated with opag 0.6.4.  */

#ifndef HDR_PARSE
#define HDR_PARSE 1

extern int parse_commandline (int argc, char *argv []);

#endif
